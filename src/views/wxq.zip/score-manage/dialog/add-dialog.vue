<script>
export default {
  name: 'AddModal',
  props: {
    visible: Boolean
  }
}
</script>

<template>
  <div>
    <el-dialog v-model="visible">
      <el-form>
        <el-form-item label="id">
          <el-input />
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>

  <style scoped lang="scss" ></style>
