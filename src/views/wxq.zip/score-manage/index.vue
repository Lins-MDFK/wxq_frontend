<template>
  <div class="user-manager-container">
    <el-card style="padding: 20px;box-sizing: border-box;">
      <div slot="header">
        成绩管理
      </div>
      <el-table
        :data="tableData"
        border
        style="width: 100%"
        fit
      >
        <el-table-column
          prop="id"
          label="id"
          sortable
        />
        <el-table-column
          prop="username"
          label="姓名"
        />
        <el-table-column
          prop="major"
          label="专业"
        />
        <el-table-column
          prop="score"
          label="成绩"
        />
        <el-table-column
          prop="update_time"
          label="更新时间"
        />
        <el-table-column
          prop="create_time"
          label="创建时间"
        />
        <el-table-column
          prop="role"
          label="身份"
        />
        <el-table-column
          fixed="right"
          label="操作"
        >
          <template>
            <el-button type="text" size="small" @click="openUpdateDialog">编辑</el-button>
            <div style="display: inline-flex; margin-left: 10px">
              <el-popconfirm
                confirm-button-text="确认"
                cancel-button-text="点错了"
                icon="el-icon-info"
                icon-color="red"
                title="这是个危险操作, 确认要删除吗？"
              >
                <el-button slot="reference" type="text" size="small">删除</el-button>

              </el-popconfirm>

            </div>

          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <add-dialog :visible.sync="addDialogVisible" />
    <update-dialog :visible.sync="updateDialogVisible" />
  </div>
</template>
<script>
import UpdateDialog from './dialog/update-dialog.vue'
import AddDialog from './dialog/add-dialog.vue'
export default {
  components: {
    UpdateDialog,
    AddDialog
  },
  data() {
    return {
      tableData: [{
        id: '1',
        update_time: '2016-05-02',
        create_time: '2016-05-02',
        username: '李二狗',
        role: '学生',
        major: '软件工程',
        score: '123'
      }],
      addDialogVisible: false,
      updateDialogVisible: false
    }
  },
  methods: {
    handleClick(row) {
      console.log(row)
    },
    openAddDialog() {
      this.addDialogVisible = true
    },
    openUpdateDialog() {
      this.updateDialogVisible = true
    }

  }
}
</script>
